const express = require('express');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

const router = express.Router();
const DATA_FILE = path.join(__dirname, '..', 'data', 'messages.json');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function readMessages() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw || '[]');
  } catch (err) {
    return [];
  }
}

function writeMessages(messages) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(messages, null, 2), 'utf-8');
}

function buildTransport() {
  if (process.env.SEND_EMAIL !== 'true') return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
}

// POST /api/contact — validate, store, and (optionally) email a submission
router.post('/', async (req, res) => {
  const { name, email, phone, acreage, interest, message } = req.body || {};

  // Server-side validation (never trust the client alone)
  const errors = [];
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    errors.push('Please provide your full name.');
  }
  if (!email || typeof email !== 'string' || !EMAIL_RE.test(email.trim())) {
    errors.push('Please provide a valid email address.');
  }
  if (!message || typeof message !== 'string' || message.trim().length < 10) {
    errors.push('Please provide a message of at least 10 characters.');
  }

  if (errors.length) {
    return res.status(400).json({ success: false, message: errors.join(' ') });
  }

  const entry = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    name: name.trim(),
    email: email.trim(),
    phone: phone ? String(phone).trim() : null,
    acreage: acreage || null,
    interest: interest || null,
    message: message.trim(),
    submittedAt: new Date().toISOString(),
  };

  try {
    const messages = readMessages();
    messages.push(entry);
    writeMessages(messages);
  } catch (err) {
    console.error('Failed to persist contact message:', err);
    return res.status(500).json({ success: false, message: 'Could not save your message. Please try again.' });
  }

  // Optional: send a notification email if SMTP is configured
  try {
    const transport = buildTransport();
    if (transport) {
      await transport.sendMail({
        from: `"FarmGrow Website" <${process.env.SMTP_USER}>`,
        to: process.env.CONTACT_TO_EMAIL || process.env.SMTP_USER,
        replyTo: entry.email,
        subject: `New contact form submission from ${entry.name}`,
        text: [
          `Name: ${entry.name}`,
          `Email: ${entry.email}`,
          `Phone: ${entry.phone || '—'}`,
          `Farm size: ${entry.acreage || '—'}`,
          `Interested in: ${entry.interest || '—'}`,
          '',
          entry.message,
        ].join('\n'),
      });
    }
  } catch (err) {
    // Don't fail the request if email delivery fails — the message is already saved.
    console.error('Email notification failed:', err);
  }

  return res.status(200).json({ success: true, message: 'Message received.' });
});

// GET /api/contact — list stored submissions.
// Demo-only endpoint: add real authentication before using this in production.
router.get('/', (req, res) => {
  const messages = readMessages();
  res.json({ success: true, count: messages.length, messages });
});

module.exports = router;
