# FarmGrow — AI Farming Website

A 6-page marketing site (Home, About, Services/Courses, Blog, Gallery, Contact) with a working contact form backed by a small Node/Express API.

## Structure

```
FarmGrow/
├── frontend/           Static site (HTML/CSS/JS)
│   ├── index.html
│   ├── about.html
│   ├── services.html
│   ├── blog.html
│   ├── gallery.html
│   ├── contact.html
│   ├── css/style.css
│   └── js/main.js
└── backend/            Express API (contact form)
    ├── server.js
    ├── routes/contact.js
    ├── data/messages.json   (submissions are saved here)
    ├── package.json
    └── .env.example
```

## Run it

```bash
cd backend
npm install
cp .env.example .env
npm start
```

Then open **http://localhost:5000** — the backend serves the frontend pages *and* the `/api/contact` endpoint from the same server, so the contact form works out of the box with no extra configuration.

(If you'd rather run the frontend on its own, e.g. with VS Code's Live Server, the form's `fetch('/api/contact')` call expects the backend at the same origin — either proxy `/api` to port 5000, or edit the fetch URL in `js/main.js` to `http://localhost:5000/api/contact`.)

## Contact form behavior

- **Client-side**: `js/main.js` validates required fields and email format before submitting, shows a loading state on the button, and displays a success or error message inline.
- **Server-side**: `routes/contact.js` re-validates everything (never trust the client alone), saves each submission to `backend/data/messages.json`, and returns a JSON response.
- **Email notifications (optional)**: set `SEND_EMAIL=true` in `.env` and fill in the `SMTP_*` values to have each submission also emailed to `CONTACT_TO_EMAIL`. Leave it `false` to just store submissions to disk (useful for local development/demoing).
- **Rate limiting**: `/api/contact` is capped at 20 requests per 15 minutes per IP to deter spam.
- **Viewing submissions**: `GET /api/contact` returns everything stored so far. This has no auth — add real authentication before using this in production.

## Design notes

- Palette and type are themed around a "field & ledger" concept — soil/harvest tones paired with a data-telemetry accent (the scrolling ticker bar under the nav, and the sensor-node illustration in the hero) to tie "farming" and "AI" together visually.
- Fully responsive: the nav collapses to a slide-in mobile menu under 760px, grids stack to one or two columns, and the gallery/forms reflow for small screens.
- Gallery tiles use CSS gradients + captions rather than stock photos — swap in real photography by replacing the `.gallery-item` background with an `<img>` or `background-image`.

## Extending it

- Blog posts currently link to `#`; wire `blog.html` cards up to real article pages or a CMS/API as content grows.
- The "Enroll now" / "Get started" buttons all point to `contact.html`; connect them to real checkout/enrollment flows when ready.
